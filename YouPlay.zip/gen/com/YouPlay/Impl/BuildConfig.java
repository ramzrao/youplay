/** Automatically generated file. DO NOT MODIFY */
package com.YouPlay.Impl;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}